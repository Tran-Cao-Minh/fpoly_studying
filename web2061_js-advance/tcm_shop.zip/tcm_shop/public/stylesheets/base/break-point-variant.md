 
$ 
  --sm-break-point: 575.98px;
 
  --md-break-point: 767.98px;

  --lg-break-point: 991.98px;

  --xl-break-point: 1199.98px;

  --xxl-break-point: 1399.98px;
$