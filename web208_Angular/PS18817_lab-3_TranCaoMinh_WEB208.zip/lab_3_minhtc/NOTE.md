# Prepare
- create project: ng new lab_3_minhtc
- move to project and run: ng serve --o
- get CDN and use in index.html
+ use terminal special with some config + save terminal history file

# Create components and layouts
- create simple layout for app component
- create functionName for each function to open its component
- ng g c [productList, productDetail, contact, login]
- create product interface and write some data
- use bootstrap icon
- show product detail by get data througth @Output + @Input
+ convert to english, good code format and logic
+ format data to show UI, UX
+ beautiful UI, UX with boostrap
+ create product detail page