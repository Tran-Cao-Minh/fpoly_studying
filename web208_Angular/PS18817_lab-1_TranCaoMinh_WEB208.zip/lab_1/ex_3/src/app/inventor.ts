export default interface Inventor {
  id: number;
  lastName: string;
  firstName: string;
  birthYear: number;
  deathYear: number;
}