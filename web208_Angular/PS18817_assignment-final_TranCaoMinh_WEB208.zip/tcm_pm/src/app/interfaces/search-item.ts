export interface SearchItem {
  id?: number;
  name?: string;
  type?: string;
}
