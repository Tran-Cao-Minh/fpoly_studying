export interface Task {
  id?: number;
  name?: string;
  description?: string;
  projectId?: number;
  projectName?: string;
  employeeId?: number;
  employeeName?: string;
  priorityId?: number;
  statusId?: number;
}
