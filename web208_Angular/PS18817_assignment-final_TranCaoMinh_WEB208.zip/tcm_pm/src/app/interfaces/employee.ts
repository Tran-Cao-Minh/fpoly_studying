export interface Employee {
  id?: number;
  lastName?: string;
  firstName?: string;
  birthDate?: string;
  genderId?: number;
  areaId?: number;
  avatar?: string;
}
