- open mysql workbench
- open terminal ng serve --o for client
- and node sever.js for backend

- all bugs can search in google fast
- if bug in mysql:
- open mysql command line client
- endter password and config for native_password
