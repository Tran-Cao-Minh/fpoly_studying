export interface SubAttribute {
  id: number;
  name: string;
}
